自由账本 V7 — 银行同步开发版（尚未通过真实银行端到端测试）
1. 先备份旧站账本。将此目录内容上传至 GitHub wall609/finance-app（保留 api/bank.js 的目录位置），Vercel 自动重新部署。不要上传任何真实账单、密码、密钥。
2. Vercel 项目的 Storage / Marketplace 创建 Upstash Redis，连接 finance-app，Production 环境；确认注入 UPSTASH_REDIS_REST_URL 和 UPSTASH_REDIS_REST_TOKEN 或 KV_REST_API_URL / KV_REST_API_TOKEN。不要使用只读 token。
3. 在项目 Production 环境中添加：APP_PASSWORD（本人密码管理器生成至少16字符随机密码）、APP_SESSION_KEY（独立生成至少32字符随机密钥，切勿更换，否则旧令牌无法解密）。不要给他人或放 GitHub。
4. Plaid 初始测试使用 PLAID_ENV=sandbox，PLAID_CLIENT_ID 和 Sandbox secret（PLAID_SECRET）。Plaid Dashboard 登记 OAuth redirect URI: https://finance-app-zeta-mauve.vercel.app/ 。正式审核完成后，替换 PLAID_SECRET 为 Production secret，并设 PLAID_ENV=production。所有设置仅在 Vercel 后端；重新部署。
5. 打开 https://finance-app-zeta-mauve.vercel.app/ -> 资产 -> 银行自动同步 -> 登录。添加银行/信用卡及投资账户；在正式环境仅连接本人真实账户，勿反复授权消耗 Trial Item 数量。
6. 打开时查询 /accounts/get（可能缓存），点击刷新请求 /accounts/balance/get（账户支持情况因机构而异）。试用数据不会纳入净资产。真实账户若已手动记录须去掉重复账户，再选择纳入净资产。记录仅留旧站本地，先导出备份再导入新站。银行 API 受登录保护；本地账单仍在浏览器存储，不是云同步。
注意：此版本没有真实连接测试、后台定时任务、交易自动导入或持仓明细；仅余额同步。密码登录非银行级认证；正式使用前应测试安全性，检查访问权限和错误处理。不要将密钥发给任何人。若密钥泄露立即轮换。服务端令牌加密保存在 Redis。
